/* Protocol.java * /
package org.xlattice

/**
    * Abstracts a family of messages.
    *
    * @author Jim Dixon
    */
public interface Protocol {

    public String name()
}

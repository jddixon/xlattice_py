# xlattice_py/xlattice/u/__init__.py

import hashlib
import sha3         # should follow hashlib

import binascii
import io
import os
import re
import shutil
import time
import rnglib

from xlattice import Q, check_using_sha

__all__ = ['__version__', '__version_date__',
           'SHA1_BIN_NONE', 'SHA2_BIN_NONE', 'SHA3_BIN_NONE',
           'SHA1_HEX_NONE', 'SHA2_HEX_NONE', 'SHA3_HEX_NONE',
           'SHA1_B64_NONE',

           # classes
           'UDir', 'ULock',
           'XLUError',

           # functions
           'file_sha1bin', 'file_sha1hex',
           'file_sha2bin', 'file_sha2hex',
           'file_sha3bin', 'file_sha3hex',

           # SYNONYMS
           'file_sha1bin', 'file_sha1hex',
           'file_sha2bin', 'file_sha2hex',
           'file_sha3bin', 'file_sha3hex',
           ]

# CONSTANTS =========================================================

# This is the SHA1 of an empty string (or file)
#                ....x....1....x....2....x....3....x....4
SHA1_HEX_NONE = 'da39a3ee5e6b4b0d3255bfef95601890afd80709'

# The same value base64
SHA1_B64_NONE = '2jmj7l5rSw0yVb/vlWAYkK/YBwk='

# The SHA2(56) of an empty string or file
#    ....x....1....x....2....x....3....x....4....x....5....x....6....
SHA2_HEX_NONE   =\
    'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# The SHA3-(56) of an empty string or file
#    ....x....1....x....2....x....3....x....4....x....5....x....6....
SHA3_HEX_NONE   =\
    'a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a'

# The lengths of SHA byte arrays or hex strings respectively
SHA1_BIN_LEN = 20
SHA1_HEX_LEN = 40
SHA2_BIN_LEN = 32
SHA2_HEX_LEN = 64
SHA3_BIN_LEN = 32
SHA3_HEX_LEN = 64

# Binary values
SHA1_BIN_NONE = binascii.a2b_hex(SHA1_HEX_NONE)
SHA2_BIN_NONE = binascii.a2b_hex(SHA2_HEX_NONE)
SHA3_BIN_NONE = binascii.a2b_hex(SHA3_HEX_NONE)

# == HACKS ==========================================================

# The next line needs to be synchronized
RNG = rnglib.SimpleRNG(time.time())

# == SYNONYMS =======================================================
#


def fileSHA1Bin(path):
    """ SYNONYM """
    return file_sha1bin(path)


def fileSHA1Hex(path):
    """ SYNONYM """
    return file_sha1hex(path)


def fileSHA2Bin(path):
    """ SYNONYM """
    return file_sha2bin(path)


def fileSHA2Hex(path):
    """ SYNONYM """
    return file_sha2hex(path)


def fileSHA3Bin(path):
    """ SYNONYM """
    return file_sha3bin(path)


def fileSHA3Hex(path):
    """ SYNONYM """
    return file_sha3hex(path)

# END SYN

# - fileSHA1 --------------------------------------------------------


def file_sha1bin(path):
    if path is None or not os.path.exists(path):
        return None

    dVal = hashlib.sha1()
    f = io.FileIO(path, 'rb')
    regexes = io.BufferedReader(f)
    while (True):
        byteStr = regexes.read(io.DEFAULT_BUFFER_SIZE)
        if (len(byteStr) == 0):
            break
        dVal.update(byteStr)
    regexes.close()
    return bytes(dVal.digest())    # a binary value


def file_sha1hex(path):
    if path is None or not os.path.exists(path):
        return None

    dVal = hashlib.sha1()
    f = io.FileIO(path, 'rb')
    regexes = io.BufferedReader(f)
    while (True):
        byteStr = regexes.read(io.DEFAULT_BUFFER_SIZE)
        if (len(byteStr) == 0):
            break
        dVal.update(byteStr)
    regexes.close()
    return dVal.hexdigest()    # a string, of course!


def file_sha2bin(path):
    if path is None or not os.path.exists(path):
        return None

    dVal = hashlib.sha256()
    f = io.FileIO(path, 'rb')
    regexes = io.BufferedReader(f)
    while (True):
        byteStr = regexes.read(io.DEFAULT_BUFFER_SIZE)
        if (len(byteStr) == 0):
            break
        dVal.update(byteStr)
    regexes.close()
    return bytes(dVal.digest())   # a binary value


def file_sha2hex(path):
    if path is None or not os.path.exists(path):
        return None

    dVal = hashlib.sha256()
    f = io.FileIO(path, 'rb')
    regexes = io.BufferedReader(f)
    while (True):
        byteStr = regexes.read(io.DEFAULT_BUFFER_SIZE)
        if (len(byteStr) == 0):
            break
        dVal.update(byteStr)
    regexes.close()
    return dVal.hexdigest()    # a string, of course!


def file_sha3bin(path):
    if path is None or not os.path.exists(path):
        return None

    dVal = hashlib.sha3_256()
    f = io.FileIO(path, 'rb')
    regexes = io.BufferedReader(f)
    while (True):
        byteStr = regexes.read(io.DEFAULT_BUFFER_SIZE)
        if (len(byteStr) == 0):
            break
        dVal.update(byteStr)
    regexes.close()
    return bytes(dVal.digest())   # a binary value


def file_sha3hex(path):
    if path is None or not os.path.exists(path):
        return None

    dVal = hashlib.sha3_256()
    f = io.FileIO(path, 'rb')
    regexes = io.BufferedReader(f)
    while (True):
        byteStr = regexes.read(io.DEFAULT_BUFFER_SIZE)
        if (len(byteStr) == 0):
            break
        dVal.update(byteStr)
    regexes.close()
    return dVal.hexdigest()    # a string, of course!

# CLASSES ===========================================================


class XLUError(RuntimeError):
    pass


class ULock(object):

    def __init__(self, u_path='/var/U'):
        self._pid = os.getpid()
        abs_path_to_u = os.path.abspath(u_path)
        self._lock_dir = '/tmp/u' + abs_path_to_u
        if (not os.path.exists(self.lock_dir)):
            os.makedirs(self._lock_dir)
            # KNOWN PROBLEM: we may have created several directories
            # but only the bottom one is 0777
            os.chmod(self.lock_dir, 0o777)
        self._lock_file = "%s/%d" % (self._lock_dir, self._pid)

    @property
    def lock_dir(self):
        return self._lock_dir

    @property
    def lock_file(self):
        return self._lock_file

    @property
    def pid(self):
        return self._pid

    # - get_lock ------------------------------------------
    def get_lock(self, verbose=False):
        """
        Try to get a lock on uPath, returning True if successful, False
        otherwise.
        """
        if (os.path.exists(self.lock_file)):
            old_pid = ''
            with open(self.lock_file, 'r') as f:
                old_pid = int(f.read())
            if verbose:
                print('%s is already locked by process %s' % (self.lock_dir,
                                                              self.pid))
            return False
        else:
            with open(self.lock_file, 'w') as f:
                f.write(str(self._pid))
            return True

    # - release_lock -------------------------------------
    def release_lock(self):
        if (os.path.exists(self.lock_file)):
            os.remove(self.lock_file)

    # SYNONYMS ------------------------------------------------------
    getLock = get_lock
    lockDir = lock_dir
    lockFile = lock_file
    releaseLock = release_lock
    # END SYN -------------------------------------------------------


class UDir (object):

    DIR_FLAT = 0
    DIR16x16 = 1
    DIR256x256 = 2
    DIR_STRUC_MAX = 3

    DIR_STRUC_NAMES = ['DIR_FLAT', 'DIR16x16', 'DIR256x256', ]

    HEX_FILE_NAME_1_PAT = r'^[0-9a-fA-F]{40}$'
    HEX_FILE_NAME_2_PAT = r'^[0-9a-fA-F]{64}$'

    HEX_DIR_NAME_16_PAT = r'^[0-9a-fA-F]{1}$'    # single hex digit
    HEX_DIR_NAME_256_PAT = r'^[0-9a-fA-F]{2}$'   # two hex digits

    HEX_FILE_NAME_1_RE = re.compile(HEX_FILE_NAME_1_PAT)
    HEX_FILE_NAME_2_RE = re.compile(HEX_FILE_NAME_2_PAT)

    HEX_DIR_NAME_16_RE = re.compile(HEX_DIR_NAME_16_PAT)
    HEX_DIR_NAME_256_RE = re.compile(HEX_DIR_NAME_256_PAT)

    _name_to_dir_struc = {
        'DIR_FLAT': DIR_FLAT,
        'DIR16x16': DIR16x16,
        'DIR256x256': DIR256x256,
    }

    def name_to_dir_struc(string):
        """ map a string into an integer"""
        return UDir._name_to_dir_struc[string]

    _dir_struc_to_name = {
        DIR_FLAT: 'DIR_FLAT',
        DIR16x16: 'DIR16x16',
        DIR256x256: 'DIR256x256',
    }

    def dir_struc_to_name(n):
        """ map an integer into a string """
        return UDir._dir_struc_to_name[n]

    def dir_struc_sig(u_path, dir_struc, using_sha):
        """ signatures differentiating different types of directories """
        if using_sha == Q.USING_SHA1:
            none = SHA1_HEX_NONE
        elif using_sha == Q.USING_SHA2:
            none = SHA2_HEX_NONE
        elif using_sha == Q.USING_SHA3:
            none = SHA3_HEX_NONE
        if dir_struc == UDir.DIR_FLAT:
            sig = os.path.join(u_path, none)
        elif dir_struc == UDir.DIR16x16:
            sig = os.path.join(u_path,
                               os.path.join(none[0],
                                            os.path.join(none[1], none)))
        elif dir_struc == UDir.DIR256x256:
            sig = os.path.join(u_path,
                               os.path.join(none[0:2],
                                            os.path.join(none[2:4], none)))
        else:
            raise XLUError('invalid dir_struc %d' % dir_struc)

        return sig

    def __init__(self, u_path, dir_struc=DIR_FLAT,
                 using_sha=Q.USING_SHA2, mode=0o755):

        self._u_path = u_path
        self._dir_struc = dir_struc
        self._using_sha = using_sha

        os.makedirs(self._u_path, mode=mode, exist_ok=True)

        # simplistic aids to discovery

        if using_sha == Q.USING_SHA1:
            pathToSig = self.get_path_for_key(SHA1_HEX_NONE)
        elif using_sha == Q.USING_SHA2:
            pathToSig = self.get_path_for_key(SHA2_HEX_NONE)
        elif using_sha == Q.USING_SHA3:
            pathToSig = self.get_path_for_key(SHA3_HEX_NONE)
        else:
            raise XLUError('unexpected Q.USING_SHAx value %d' % using_sha)
        sig_base = os.path.dirname(pathToSig)
        os.makedirs(sig_base, exist_ok=True)
        open(pathToSig, 'a').close()                # touch

        self._inDir = os.path.join(u_path, 'in')
        os.makedirs(self._inDir, mode=mode, exist_ok=True)
        self._tmpDir = os.path.join(u_path, 'tmp')
        os.makedirs(self._tmpDir, mode=mode, exist_ok=True)

    @property
    def dir_struc(self): return self._dir_struc

    @property
    def u_path(self): return self._u_path

    @property
    def using_sha(self): return self._using_sha

    @classmethod
    def discover(cls, u_path, dir_struc=DIR_FLAT,
                 using_sha=Q.USING_SHA2, mode=0o755):
        """
        If there is a directory at the expected path, return an
        appropriate tree with the directory structure found.  Otherwise
        create a directory with the characteristics suggested by the
        parameters.

        When a directory tree is created we write NONE into the tree
        as an aid to discovery.  If this is SHA1_HEX_NONE, for example,
        we discover that using_sha is True.  If NONE is in the top
        directory, the directory structure is DIR_FLAT.  If its first
        byte is in the top directory, dir_struc is DIR16x16.  If its
        first two bytes are there, it is DIR256x256.
        """

        check_using_sha(using_sha)
        if os.path.exists(u_path):
            found = False

            # check for flat directory structure --------------------
            if not found:
                flat_sha1_path = os.path.join(u_path, SHA1_HEX_NONE)
                if os.path.exists(flat_sha1_path):
                    found = True
                    dir_struc = UDir.DIR_FLAT
                    using_sha = Q.USING_SHA1
            if not found:
                flat_sha2_path = os.path.join(u_path, SHA2_HEX_NONE)
                if os.path.exists(flat_sha2_path):
                    found = True
                    dir_struc = UDir.DIR_FLAT
                    using_sha = Q.USING_SHA2
            if not found:
                flat_sha3_path = os.path.join(u_path, SHA3_HEX_NONE)
                if os.path.exists(flat_sha3_path):
                    found = True
                    dir_struc = UDir.DIR_FLAT
                    using_sha = Q.USING_SHA3

            # check for 16x16 directory structure -------------------
            if not found:
                dir16_sha1_path = os.path.join(u_path,
                                               os.path.join(SHA1_HEX_NONE[0],
                                                            os.path.join(SHA1_HEX_NONE[1],
                                                                         SHA1_HEX_NONE)))
                if os.path.exists(dir16_sha1_path):
                    found = True
                    dir_struc = UDir.DIR16x16
                    using_sha = Q.USING_SHA1
            if not found:
                dir16_sha2_path = os.path.join(u_path,
                                               os.path.join(SHA2_HEX_NONE[0],
                                                            os.path.join(SHA2_HEX_NONE[1],
                                                                         SHA2_HEX_NONE)))
                if os.path.exists(dir16_sha2_path):
                    found = True
                    dir_struc = UDir.DIR16x16
                    using_sha = Q.USING_SHA2
            if not found:
                dir16_sha3_path = os.path.join(u_path,
                                               os.path.join(SHA3_HEX_NONE[0],
                                                            os.path.join(SHA3_HEX_NONE[1],
                                                                         SHA3_HEX_NONE)))
                if os.path.exists(dir16_sha3_path):
                    found = True
                    dir_struc = UDir.DIR16x16
                    using_sha = Q.USING_SHA3

            # check for 256x256 directory structure -----------------
            if not found:
                dir256_sha1_path = os.path.join(u_path,
                                                os.path.join(SHA1_HEX_NONE[0:2],
                                                             os.path.join(SHA1_HEX_NONE[2:4],
                                                                          SHA1_HEX_NONE)))
                if os.path.exists(dir256_sha1_path):
                    found = True
                    dir_struc = UDir.DIR256x256
                    using_sha = Q.USING_SHA1
            if not found:
                dir256_sha2_path = os.path.join(u_path,
                                                os.path.join(SHA2_HEX_NONE[0:2],
                                                             os.path.join(SHA2_HEX_NONE[2:4],
                                                                          SHA2_HEX_NONE)))
                if os.path.exists(dir256_sha2_path):
                    found = True
                    dir_struc = UDir.DIR256x256
                    using_sha = Q.USING_SHA2
            if not found:
                dir256_sha3_path = os.path.join(u_path,
                                                os.path.join(SHA3_HEX_NONE[0:2],
                                                             os.path.join(SHA3_HEX_NONE[2:4],
                                                                          SHA3_HEX_NONE)))
                if os.path.exists(dir256_sha3_path):
                    found = True
                    dir_struc = UDir.DIR256x256
                    using_sha = Q.USING_SHA3

        # if uDir does not already exist, this creates it
        obj = cls(u_path, dir_struc, using_sha, mode)
        return obj

    def copy_and_put(self, path, key):
        """
        Make a local copy of the file at path and with the content key
        specified, then move the file into U.  Return the length of the
        file and its actual content key.
        """

        # XXX we do two such stats on this file
        actualLength = os.stat(path).st_size

        # RACE CONDITION
        tmpFileName = os.path.join(self._tmpDir, RNG.nextFileName(16))
        while os.path.exists(tmpFileName):
            tmpFileName = os.path.join(self._tmpDir, RNG.nextFileName(16))

        shutil.copyfile(path, tmpFileName)
        length, hash = self.put(tmpFileName, key)

        # integrity check
        if length != actualLength:
            print("put of %s: actual length %d, returned length %d" % (
                path, actualLength, lenght))

        # DEBUG - DO NOT REMOVE THIS CASUALLY =======================
        if hash != key or path.endswith('uildList') or path.endswith('builds'):
            print('putting %s\n\tkey  %s\n\thash %s' % (path, key, hash))
        # END =======================================================

        return length, hash

    def delete(self, key):
        """
        If there is a file in the store with the hexadecimal content key
        specified, delete it and return True.  Otherwise return False.

        """
        path = self.get_path_for_key(key)
        if not os.path.exists(path):
            return False
        else:
            os.unlink(path)
            return True

    def get_data(self, key):
        """
        If there is a file in the store with the content key specified,
        return it.  Otherwise return None.

        XXX The file must fit in memory.
        """
        path = self.get_path_for_key(key)
        if not os.path.exists(path):
            return None
        else:
            with open(path, 'rb') as f:
                data = f.read()
            return data

    def put(self, inFile, key):
        """
        inFile is the path to a local file which will be renamed into U (or
        deleted if it is already present in U) key is an sha1 or sha256
        content hash.  If the operation succeeds we return a 2-tuple
        containing the length of the file, which must not be zero, and its
        hash.  Otherwise we return (0, '').
        """

        keyLen = len(key)
        errMsg = ''
        if self.using_sha == Q.USING_SHA1 and keyLen != SHA1_HEX_LEN:
            errMsg = "UDir.put: expected key length 40, actual %d" % keyLen
        elif self.using_sha == Q.USING_SHA2 and keyLen != SHA2_HEX_LEN:
            errMsg = "UDir.put: expected key length 64, actual %d" % keyLen
        elif self.using_sha == Q.USING_SHA3 and keyLen != SHA3_HEX_LEN:
            errMsg = "UDir.put: expected key length 64, actual %d" % keyLen
        # XXX BAD USING OR LEN NOT ALLOWED FOR
        if errMsg:
            raise XLUError(errMsg)

        if self.using_sha == Q.USING_SHA1:
            hash = file_sha1hex(inFile)
        elif self.using_sha == Q.USING_SHA2:
            hash = file_sha2hex(inFile)
        elif self.using_sha == Q.USING_SHA3:
            hash = file_sha3hex(inFile)
        # XXX BAD USING OR LEN NOT ALLOWED FOR
        length = os.stat(inFile).st_size

        if self.dir_struc == UDir.DIR_FLAT:
            fullishPath = os.path.join(self.u_path, key)
        else:
            if self.dir_struc == UDir.DIR16x16:
                topSubDir = hash[0]
                lowerDir = hash[1]
            elif self.dir_struc == UDir.DIR256x256:
                topSubDir = hash[0:2]
                lowerDir = hash[2:4]
            else:
                raise XLUError("unknown dir_struc %d" % self.dir_struc)
            targetDir = self.u_path + '/' + topSubDir + '/' + lowerDir + '/'
            if not os.path.exists(targetDir):
                os.makedirs(targetDir)
            fullishPath = targetDir + key

        if (os.path.exists(fullishPath)):
            os.unlink(inFile)
        else:
            shutil.move(inFile, fullishPath)
            os.chmod(fullishPath, 0o444)

        return (length, hash)

    def put_data(self, data, key):
        if self.using_sha == Q.USING_SHA1:
            sha = hashlib.sha1()
        elif self.using_sha == Q.USING_SHA2:
            sha = hashlib.sha256()
        elif self.using_sha == Q.USING_SHA3:
            sha = hashlib.sha3_256()
        sha.update(data)
        hash = sha.hexdigest()
        length = len(data)

        if self.dir_struc == UDir.DIR_FLAT:
            fullishPath = os.path.join(self.u_path, key)
        else:
            if self.dir_struc == UDir.DIR16x16:
                topSubDir = hash[0]
                lowerDir = hash[1]
            elif self.dir_struc == UDir.DIR256x256:
                topSubDir = hash[0:2]
                lowerDir = hash[2:4]
            else:
                raise XLUError("undefined dir_struc %d" % self.dir_struc)

            targetDir = self.u_path + '/' + topSubDir + '/' + lowerDir + '/'
            if not os.path.exists(targetDir):
                os.makedirs(targetDir)
            fullishPath = targetDir + key

        if (os.path.exists(fullishPath)):
            # print "DEBUG: file is already present"
            pass
        else:
            with open(fullishPath, 'wb') as f:
                f.write(data)

        # XXX UNSATISFACTORY HANDLING OF THE ERROR
        if (hash != key):
            errMsg = "put_data:\n\texpected key %s\n\tcontent hash %s" % (
                key, hash)
            print(errMsg)

        return (length, hash)               # GEEP2

    def exists(self, key):
        """ key is hexadecimal content key """

        # CHECK KEY LEN

        path = self.get_path_for_key(key)
        return os.path.exists(path)

    def file_len(self, key):
        """
        returns the length of the file with the given content key
        """

        # CHECK KEY LEN

        path = self.get_path_for_key(key)
        return os.stat(path).st_size

    def get_path_for_key(self, key):
        """
        returns a path to a file with the content key passed, or None if
        there is no such file
        """
        if self.dir_struc == UDir.DIR_FLAT:
            return os.path.join(self.u_path, key)

        if self.dir_struc == UDir.DIR16x16:
            topSubDir = key[0]
            lowerDir = key[1]
        elif self.dir_struc == UDir.DIR256x256:
            topSubDir = key[0:2]
            lowerDir = key[2:4]
        else:
            raise XLUError("unexpected dir_struc %d" % self.dir_struc)

        return self.u_path + '/' + topSubDir + '/' + lowerDir + '/' + key

    def re_struc(self, newStruc):
        """
        Change the structure of uDir to the new dir_struc specified,
        where newStruc is a small non-negative integer.
        """
        old_struc = self.dir_struc
        old_sig = UDir.dir_struc_sig(
            self.u_path, self.dir_struc, self.using_sha)
        new_sig = UDir.dir_struc_sig(self.u_path, newStruc, self.using_sha)

        # fix signature
        if new_sig != old_sig:
            if os.path.exists(old_sig):
                os.unlink(old_sig)
            if not os.path.exists(new_sig):
                sig_base = os.path.dirname(new_sig)
                os.makedirs(sig_base, exist_ok=True)
                open(new_sig, 'a').close()                # touch
        self._dir_struc = newStruc

        self._simple_restruc(old_struc, newStruc)

    def _simple_restruc(self, old_struc, newStruc):
        """
        Scan the directory structure looking for files whose name=content hash
        of the right length for the SHA used (so 40 bytes for SHA1, 64 for SHA2/3)
        but in the wrong directory.  Out-of-place files are moved to the correct
        directory.
        """

        path_to_top = self.u_path
        # DEBUG
        # print("path_to_top: %s" % path_to_top)
        # END
        if old_struc == UDir.DIR_FLAT:
            for key in os.listdir(path_to_top):
                if self.using_sha == Q.USING_SHA1:
                    m = self.HEX_FILE_NAME_1_RE.match(key)
                elif self.using_sha == Q.USING_SHA2:
                    m = self.HEX_FILE_NAME_2_RE.match(key)
                elif self.using_sha == Q.USING_SHA3:
                    m = self.HEX_FILE_NAME_3_RE.match(key)
                if m:
                    # DEBUG
                    # print("match: %s" % key)
                    # END
                    path_to_file = os.path.join(path_to_top, key)
                    self.put(path_to_file, key)

        else:
            # old_struc == UDir.DIR16x16 or UDir.DIR256x256
            if old_struc == UDir.DIR16x16:
                dir_re = self.HEX_DIR_NAME_16_RE
            else:
                dir_re = self.HEX_DIR_NAME_256_RE
            for midDir in os.listdir(path_to_top):
                midOccupied = False
                m = dir_re.match(midDir)
                if m:
                    pathToMid = os.path.join(path_to_top, midDir)
                    # DEBUG
                    # print("pathToMid: %s" % pathToMid)
                    # END
                    for botDir in os.listdir(pathToMid):
                        botOccupied = False
                        m = dir_re.match(botDir)
                        if m:
                            pathToBot = os.path.join(pathToMid, botDir)
                            # DEBUG
                            # print("pathToBot: %s" % pathToBot)
                            # END
                            for key in os.listdir(pathToBot):
                                if self.using_sha == Q.USING_SHA1:
                                    m = self.HEX_FILE_NAME_1_RE.match(key)
                                elif self.using_sha == Q.USING_SHA2:
                                    m = self.HEX_FILE_NAME_2_RE.match(key)
                                elif self.using_sha == Q.USING_SHA3:
                                    m = self.HEX_FILE_NAME_3_RE.match(key)
                                if m:
                                    # DEBUG
                                    # print("match at bottom: %s" % key)
                                    # END
                                    path_to_file = os.path.join(pathToBot, key)
                                    self.put(path_to_file, key)
                                else:
                                    botOccupied = True
                        if not botOccupied:
                            os.rmdir(pathToBot)
                    if not midOccupied:
                        os.rmdir(pathToMid)

        # remove old directories

    # SYNONYMS ------------------------------------------------------
    copyAndPut = copy_and_put
    dirStruc = dir_struc
    dirStrucSig = dir_struc_sig
    dirStrucToName = dir_struc_to_name
    fileLen = file_len
    getData = get_data
    getPathForKey = get_path_for_key
    nameToDirStruc = name_to_dir_struc
    putData = put_data
    reStruc = re_struc
    uPath = u_path
    usingSHA = using_sha
    # END SYN -------------------------------------------------------

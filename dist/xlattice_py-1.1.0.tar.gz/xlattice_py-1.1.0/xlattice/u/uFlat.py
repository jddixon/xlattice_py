# xlattice_py/xlattice/u/uFlat.py

import io
import os
import shutil
import time
import hashlib
import sys
import rnglib  # for rnglib.nextFileName
from xlattice import u

__all__ = [
    'copyAndPut1', 'getData1', 'put1', 'putData1',
    'copyAndPut2', 'getData2', 'put2', 'putData2',
    # should be same code for u1 and u2
    'exists', 'fileLen', 'getPathForKey',

    # classes -------------------------------------
    'ULock',                # used??
]

# CONSTANTS =========================================================

RNG = rnglib.SimpleRNG(time.time())

# SHA1-BASED uFlat METHODS ==========================================

#- copyAndPut1 -------------------------------------------------------


def copyAndPut1(path, uPath, key):
    # the temporary file MUST be created on the same device
    tmpDir = os.path.join(uPath, 'tmp')
    # xxx POSSIBLE RACE CONDITION
    tmpFileName = os.path.join(tmpDir, RNG.nextFileName(16))
    while os.path.exists(tmpFileName):
        tmpFileName = os.path.join(tmpDir, RNG.nextFileName(16))
    shutil.copyfile(path, tmpFileName)
    return put1(tmpFileName, uPath, key)

# - getData1 ---------------------------------------------------------


def getData1(uPath, key):
    path = getPathForKey(uPath, key)
    if not os.path.exists(path):
        return None
    else:
        with open(path, 'rb') as f:
            data = f.read()
        return data

# - put1 -------------------------------------------------------------
# tmp is the path to a local file which will be renamed into U (or deleted
# if it is already present in U)
# uPath is an absolute or relative path to a U directory organized 256x256
# key is an sha1 content hash.
# If the operation succeeds we return the length of the file (which must
# not be zero.  Otherwise we return 0.
# we don't do much checking


def put1(inFile, uPath, key):
    hash = u.fileSHA1Hex(inFile)
    if (hash != key):
        print("expected %s to have key %s, but the content key is %s" % (
            inFile, key, hash))
        return (0, None)
    len = os.stat(inFile).st_size

    fullishPath = os.path.join(uPath, key)
    if (os.path.exists(fullishPath)):
        os.unlink(inFile)
    else:
        os.rename(inFile, fullishPath)
        os.chmod(fullishPath, 0o444)
    return (len, hash)

# - putData1 ---------------------------------------------------------


def putData1(data, uPath, key):
    s = hashlib.sha1()
    s.update(data)
    hash = s.hexdigest()
    if (hash != key):
        print("expected data to have key %s, but the content key is %s" % (
            key, hash))
        return (0, None)        # length and hash
    length = len(data)          # XXX POINTLESS

    fullishPath = os.path.join(uPath, key)
    if (os.path.exists(fullishPath)):
        # print "DEBUG: file is already present"
        pass
    else:
        with open(fullishPath, 'wb') as f:
            f.write(data)
    return (length, hash)               # GEEP2

# SHA256-BASED u256x256 METHODS =====================================

#- copyAndPut2 ------------------------------------------------------


def copyAndPut2(path, uPath, key):
    # the temporary file MUST be created on the same device
    tmpDir = os.path.join(uPath, 'tmp')
    # xxx POSSIBLE RACE CONDITION
    tmpFileName = os.path.join(tmpDir, RNG.nextFileName(16))
    while os.path.exists(tmpFileName):
        tmpFileName = os.path.join(tmpDir, RNG.nextFileName(16))
    shutil.copyfile(path, tmpFileName)
    return put2(tmpFileName, uPath, key)

# - getData2 --------------------------------------------------------


def getData2(uPath, key):
    path = getPathForKey(uPath, key)
    if not os.path.exists(path):
        return None
    else:
        with open(path, 'rb') as f:
            data = f.read()
        return data

# - put2 ------------------------------------------------------------
# tmp is the path to a local file which will be renamed into U (or deleted
# if it is already present in U)
# uPath is an absolute or relative path to a U directory organized 256x256
# key is an sha3 content hash.
# If the operation succeeds we return the length of the file (which must
# not be zero.  Otherwise we return 0.
# we don't do much checking


def put2(inFile, uPath, key):
    hash = u.fileSHA2Hex(inFile)
    if (hash != key):
        print("expected %s to have key %s, but the content key is %s" % (
            inFile, key, hash))
        return (0, None)
    len = os.stat(inFile).st_size

    fullishPath = os.path.join(uPath, key)
    if (os.path.exists(fullishPath)):
        os.unlink(inFile)
    else:
        os.rename(inFile, fullishPath)
        os.chmod(fullishPath, 0o444)
    return (len, hash)

# - putData2 --------------------------------------------------------


def putData2(data, uPath, key):
    s = hashlib.sha256()
    s.update(data)
    hash = s.hexdigest()
    if (hash != key):
        print("expected data to have key %s, but the content key is %s" % (
            key, hash))
        return (0, None)        # length and hash
    length = len(data)          # XXX POINTLESS

    fullishPath = os.path.join(uPath, key)
    if (os.path.exists(fullishPath)):
        # print "DEBUG: file is already present"
        pass
    else:
        with open(fullishPath, 'wb') as f:
            f.write(data)
    return (length, hash)               # GEEP2

# - exists ----------------------------------------------------------


def exists(uPath, key):
    path = getPathForKey(uPath, key)
    return os.path.exists(path)

# - fileLen ---------------------------------------------------------
# returns the length of the file with the given content key


def fileLen(uPath, key):
    path = getPathForKey(uPath, key)
    return os.stat(path).st_size

# - getPathForKey ---------------------------------------------------
# returns a path to a file with the content key passed, or None if there
# is no such file


def getPathForKey(uPath, key):
    if(os.path.exists(uPath) == False):
        print("HASH %s: UDIR DOES NOT EXIST: %s" % (key, uPath))
        return None
    return os.path.join(uPath, key)
